import React from "react";
import ReactDOM from "react-dom";
import { PricingTable, PricingSlot, PricingDetail } from "react-pricing-table";

import "./styles.css";

function App() {
  return (
    <p class="fieldset">
				<input type="radio" name="duration-1" value="monthly" id="monthly-1" checked>
				<label for="monthly-1">Annually</label>
				<input type="radio" name="duration-1" value="yearly" id="yearly-1">
				<label for="yearly-1">Monthly</label>
				<span class="switch"></span>
			</p>
    <PricingTable highlightColor="#1976D2">
      <PricingSlot buttonText="LEARN MORE" title="MASTER" priceText="$19.99">
        <PricingDetail> 500 GB Storage</PricingDetail>
        <PricingDetail> 5 Users allowed</PricingDetail>
        <PricingDetail> send upto 3 GB</PricingDetail>
      </PricingSlot>
      <PricingSlot buttonText="LEARN MORE" title="Professional" priceText="$24.99">
        <PricingDetail>  1 TB Storage </PricingDetail>
        <PricingDetail> 5 Users allowed </PricingDetail>
        <PricingDetail> send upto 10 GB</PricingDetail>
        
        <PricingDetail> </PricingDetail>
      </PricingSlot>
      <PricingSlot buttonText="LEARN MORE" title="Master" priceText="$39.99">
        <PricingDetail> 1 TB Storage </PricingDetail>
        <PricingDetail> 5 Users allowed </PricingDetail>
        <PricingDetail>
          {" "}
          send upto 10 GB
        </PricingDetail>
      </PricingSlot>
    </PricingTable>
  );
}

const rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);
